<?php
$host = "localhost";
$username = "mvc-food";
$password = "19820907Wzimook";
$database = "mvc-food";
?>